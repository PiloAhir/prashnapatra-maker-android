# પ્રશ્નપત્ર મેકર — Android WebView starter

આ પ્રોજેક્ટમાં `app/src/main/assets/index.html` તરીકે સુધારેલી HTML એપ સામેલ છે. Android WebView એ જ HTML ચલાવે છે; સ્કેનિંગ માટે Gemini API હોવાથી ઇન્ટરનેટ અને માન્ય API key જરૂરી છે.

## GitHub રીપોઝિટરીમાં વાપરવાની રીત

1. પહેલાં તમારી હાલની રીપોઝિટરીનો backup/branch બનાવો.
2. આ ZIP ને extract કરો.
3. ફાઇલોને તમારી રીપોઝિટરીમાં યોગ્ય જગ્યાએ merge કરો. જો ત્યાં પહેલેથી `app`, Gradle અથવા Manifest હોય તો સીધું overwrite ન કરો; પહેલાં હાલની ફાઇલો સાથે સરખાવો.
4. `.github/workflows/build-apk.yml` ઉમેરો.
5. GitHubમાં commit/push કરો અથવા Actions tab માં `Build Android APK` ચલાવો.
6. સફળ workflow માં `prashnapatra-maker-debug-apk` artifact ડાઉનલોડ કરો.

## ખાસ નોંધ

- આ starter package છે; તમારી જૂની repository ના package name, plugins, dependencies અથવા signing setup વિશે માહિતી વગર તેને આપમેળે merge કરી શકાય તેમ નથી.
- હાલનું HTML bundled asset છે. HTMLમાં સ્કેનિંગનો code બદલાયો નથી; APK wrapper ઉમેર્યું છે.
- API key HTML/JavaScriptમાં હોય તો APKમાંથી બહાર કાઢી શકાય છે. બીજા લોકોને APK આપવાની હોય તો API key ને સુરક્ષિત backend મારફતે રાખવી યોગ્ય છે.
- `debug APK` પરીક્ષણ માટે છે; Play Store અથવા વ્યાપક વિતરણ માટે અલગ release/signing વ્યવસ્થા જરૂરી છે.
- સ્કેનિંગની વાસ્તવિક ઝડપ વધે છે કે નહીં તે વાસ્તવિક ફોન, નેટવર્ક અને Gemini API સાથે પરીક્ષણ કરીને જ નક્કી થશે.
\n\n## ફોટા પસંદ ન થતા હોય તો\n\nઆ પેકેજમાં Android WebView file chooser માટે સુધારેલો `MainActivity.kt` છે. Repositoryમાં આ ZIPને જૂની ZIP ઉપર એ જ નામથી replace કરો, commit કરો અને GitHub Actionsમાં નવો build સફળ થયા પછી નવો APK ડાઉનલોડ કરો. જૂનો APK ફરી ઇન્સ્ટોલ કરવાથી સુધારો નહીં મળે.\n